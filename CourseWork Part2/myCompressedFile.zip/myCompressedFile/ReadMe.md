The Coursework Material has been saved in a Zip file. 
The code is all in a python notebook of format type ipynb
This file is run for all the task 
The reasoning at the bottom of the file may need to be commented out or uncommented when running the file. It has been left commented out for now
The bottom sections of the notebook contains preprocessing tasks carried out to visualise the data and make sense of it. These sections can be ignored.